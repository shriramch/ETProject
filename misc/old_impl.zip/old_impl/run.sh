#! /bin/bash
python3.9 enumerator.py "z3 model_validate=true;cvc4 -q --strings-exp" 2
