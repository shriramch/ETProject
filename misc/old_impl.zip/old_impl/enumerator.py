import os
import sys
import copy
import time
import signal
import subprocess
import argparse
import logging

from antlr4.FileStream import FileStream
from SMTLIBv2Lexer import SMTLIBv2Lexer
from antlr4.CommonTokenStream import CommonTokenStream
from SMTLIBv2Parser import SMTLIBv2Parser
from antlr4.atn.Transition import AtomTransition, RuleTransition, SetTransition
from antlr4.atn.ATNState import RuleStopState

from oracle import test 
from Logger import init_logging, log_strategy_solvers, log_status


MODULO = 10

class State(object):
    def __init__(self, atn_state, atom_seq):
        self.atn_state = atn_state
        self.atom_seq = atom_seq
        self.stack = []

    def depth(self): 
        return len(self.stack) 

    def __hash__(self):
        return hash(self.atn_state) ^ hash(self.atom_seq)\
                ^ hash(frozenset(self.stack))


def handle_atom_transition(parser, transition, atn_state, atom_seqs):
    idx = atn_state.transitions[0].label[0]
    if len(atom_seqs) == 0:
        atom_seqs.append(parser.literalNames[idx])
    else:
        new_atom_seqs = []
        for a in atom_seqs:
            new_atom_seqs.append(a + parser.literalNames[idx])
        atom_seqs = new_atom_seqs
    return atom_seqs


def handle_set_transition(parser, transition, atom_seqs):
    new_atom_seqs = []
    for labl in transition.label:
        labl_s = parser.literalNames[labl]
        for a in atom_seqs:
            new_atom_seqs.append(a + labl_s)
    return new_atom_seqs


def unroll(parser, state):
    """
    Linearly walk through ATN. Continue as long as there are no decision
    points.
    """

    atn_state = copy.deepcopy(state.atn_state)
    stack = copy.deepcopy(state.stack)
    atom_seqs = [copy.deepcopy(state.atom_seq)]
    while len(atn_state.transitions) == 1:
        transition = atn_state.transitions[0]

        if isinstance(transition, AtomTransition):
            # atom transitions, e.g., s1 -label-> s2
            idx = atn_state.transitions[0].label[0]
            if idx != -1:
                atom_seqs = handle_atom_transition(parser, transition, atn_state,
                                                   atom_seqs)
        if isinstance(transition, SetTransition):
            # set transitions, e.g., s1  -{label1,...,labeln}-> s2
            atom_seqs = handle_set_transition(parser, transition, atom_seqs)

        if isinstance(transition, RuleTransition):
            # add follow state to stack
            stack.append(transition.followState)

        # Assign new atn_state after the transition
        atn_state = atn_state.transitions[0].target
        if isinstance(atn_state, RuleStopState):
            # When running into a rule stop state, return to the last automaton    
            # from which the jump was initiated. 
            if len(stack) != 0:
                atn_state = stack[-1]
                stack.pop()

    unrolled_states = []
    for seq in atom_seqs:
        new_state = State(atn_state, seq)
        new_state.stack = stack
        if new_state != state:
            unrolled_states.append(new_state)
    return unrolled_states


def get_sucessors(parser, curr):
    unrolled_states = unroll(parser, curr)
    successors = []
    for ustate in unrolled_states:
        if len(ustate.atn_state.transitions) != 0:
            for t in ustate.atn_state.transitions:
                succ_state = State(t.target,  ustate.atom_seq)
                succ_state.stack = ustate.stack
                successors.append(succ_state)
        else:
            successors.append(ustate)
    return successors


def pretty_print(state):
    s = state.atom_seq.replace("''", " ").replace("'", "")
    return s.replace("( ", "(").replace(" )", ")")


def debug(state):
    print("[State]", "id="+str(state.atn_state), "depth="+str(state.depth()), 
           "stack="+str(state.stack), "atom_seq="+str(state.atom_seq), 
           flush = True)



def dump_formula(i,formula):
    fn = "/tmp/formula"+str(i)+".smt2"
    with open(fn, "w") as f:
        f.write(formula)
    return fn


def dfs(parser, init_state, max_depth, args):
    start_timestamp = time.time()
    smt_solving_time = 0.0

    open_list = []
    closed_list = []
    open_list.append(init_state)
    num_tests = 0 
    num_bugs = 0  
    num_nodes = 0
    while len(open_list) != 0:
        curr = open_list.pop()
        if args.max_iterations != -1 and num_tests >= args.max_iterations:
            print("iteration limit reached")
            exit(0)
        num_nodes += 1
        if curr.stack == [] and curr.atom_seq != "":
            formula = pretty_print(curr) 
            if not num_tests % MODULO: 
                total_time = time.time() - start_timestamp 
                line = "num_tests="+str(num_tests)+ " num_bugs="+str(num_bugs) +\
                      " t="+str(round(total_time,4))+" t_smt="+str(round(smt_solving_time,4)) +\
                      " ("+ str(round(smt_solving_time / total_time,2))+"%)"
                log_status(line)    

            fn = dump_formula(num_tests, formula) 
            before = time.time()
            if not test(num_tests, fn, args):
                num_bugs = 0
            num_tests = num_tests + 1
            smt_solving_time += time.time() - before
            try:
                subprocess.getoutput("rm -rf "+fn)
            except:
                print("Couldn't remove "+fn, flush=True) 
            continue

        if curr not in closed_list and curr.depth() <= max_depth:
            closed_list.append(curr)
            for successor in get_sucessors(parser, curr):
                if successor.depth() <= max_depth:
                    open_list.append(successor)

    summary = "Finished search. {} tests executed, eff: XX %\n".format(num_tests)
    summary += "{} nodes generated, {:.2f}s elapsed\n".format(num_nodes,time.time() - start_timestamp)
    summary += "Proved up to depth "+ str(args.depth)+"\n"
    summary += "{} bug triggers found".format(num_bugs)
    print(summary, flush = True)

def setup(): 
    fn = "mock.smt2"
    fstream = FileStream(fn, encoding="utf8")
    lexer = SMTLIBv2Lexer(fstream)
    lexer.removeErrorListeners()
    stream = CommonTokenStream(lexer)
    parser = SMTLIBv2Parser(stream)
    rule_idx = len(parser.ruleNames) - 1
    atn = parser.atn
    atn_state = atn.ruleToStartState[rule_idx]
    return atn_state, parser


def check_executable(path):
    if not os.path.exists(path): 
        cmd = "which "+ path.strip('"').split(" ")[0]
        out = subprocess.getoutput(cmd) 
        if "" == out.strip():
            return False
    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser() 
    parser.add_argument(
        "SOLVER_CLIS",
        metavar="solver_clis",
    )
    parser.add_argument("depth", type=int, help="depth bound")
    parser.add_argument("--bugfolder", type=str, default="./bugs", help="bug folder")
    parser.add_argument("--logfolder", type=str, default="./logs", help="log folder")
    parser.add_argument("-t", "--timeout", type=int, help="timeout in secs", default=8)
    parser.add_argument("-m", "--max-iterations", type=int, 
                        help="limit number of iterations", default=-1)


    args = parser.parse_args()     
    args.SOLVER_CLIS = args.SOLVER_CLIS.split(";")
    
    for sol in args.SOLVER_CLIS:
        if not check_executable(sol): 
             print("Error: sol cfg", sol ,"is invalid", flush=True)
             exit(1)

    if not os.path.exists(args.bugfolder):
        os.mkdir("./bugs")

    if not os.path.exists(args.logfolder):
        os.mkdir("./logs")

    atn_state, parser = setup()
    init_state = State(atn_state, "")
    init_state.stack = []
    
    init_logging("exhautive_enumerator-depth-"+str(args.depth), False, "", args)
    log_strategy_solvers("dfs", args.SOLVER_CLIS)
    dfs(parser, init_state, args.depth, args)
