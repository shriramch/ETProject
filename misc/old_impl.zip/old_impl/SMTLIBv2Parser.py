# Generated from SMTLIBv2.g4 by ANTLR 4.9.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO


def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\36")
        buf.write("\u00b7\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\3\2\3\2\3\3\3\3\3\4\3\4\3\4\3\4\3\4\3\4\3\5\3\5")
        buf.write("\3\5\3\5\3\5\3\5\3\6\3\6\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3")
        buf.write("\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7")
        buf.write("\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3")
        buf.write("\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7")
        buf.write("\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3")
        buf.write("\7\3\7\3\7\3\7\3\7\5\7q\n\7\3\b\3\b\3\t\3\t\3\t\3\t\3")
        buf.write("\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t")
        buf.write("\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3")
        buf.write("\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\5\t\u009c\n\t\3\n\3\n\3")
        buf.write("\13\3\13\3\13\3\13\3\13\3\13\5\13\u00a6\n\13\3\f\3\f\3")
        buf.write("\f\3\f\3\r\3\r\3\r\3\r\3\r\3\16\3\16\3\16\3\16\3\16\3")
        buf.write("\16\3\16\2\2\17\2\4\6\b\n\f\16\20\22\24\26\30\32\2\6\3")
        buf.write("\2\3\4\3\2\7\b\3\2\20\21\3\2\30\31\2\u00bc\2\34\3\2\2")
        buf.write("\2\4\36\3\2\2\2\6 \3\2\2\2\b&\3\2\2\2\n,\3\2\2\2\fp\3")
        buf.write("\2\2\2\16r\3\2\2\2\20\u009b\3\2\2\2\22\u009d\3\2\2\2\24")
        buf.write("\u00a5\3\2\2\2\26\u00a7\3\2\2\2\30\u00ab\3\2\2\2\32\u00b0")
        buf.write("\3\2\2\2\34\35\t\2\2\2\35\3\3\2\2\2\36\37\7\5\2\2\37\5")
        buf.write("\3\2\2\2 !\7\35\2\2!\"\7\6\2\2\"#\7\3\2\2#$\5\4\3\2$%")
        buf.write("\7\36\2\2%\7\3\2\2\2&\'\7\35\2\2\'(\7\6\2\2()\7\4\2\2")
        buf.write(")*\5\4\3\2*+\7\36\2\2+\t\3\2\2\2,-\t\3\2\2-\13\3\2\2\2")
        buf.write(".q\5\n\6\2/\60\7\35\2\2\60\61\7\t\2\2\61\62\5\20\t\2\62")
        buf.write("\63\5\20\t\2\63\64\7\36\2\2\64q\3\2\2\2\65\66\7\35\2\2")
        buf.write("\66\67\7\t\2\2\678\5\24\13\289\5\24\13\29:\7\36\2\2:q")
        buf.write("\3\2\2\2;<\7\35\2\2<=\7\t\2\2=>\5\f\7\2>?\5\f\7\2?@\7")
        buf.write("\36\2\2@q\3\2\2\2AB\7\35\2\2BC\7\n\2\2CD\5\20\t\2DE\5")
        buf.write("\20\t\2EF\7\36\2\2Fq\3\2\2\2GH\7\35\2\2HI\7\n\2\2IJ\5")
        buf.write("\24\13\2JK\5\24\13\2KL\7\36\2\2Lq\3\2\2\2MN\7\35\2\2N")
        buf.write("O\7\n\2\2OP\5\f\7\2PQ\5\f\7\2QR\7\36\2\2Rq\3\2\2\2ST\7")
        buf.write("\35\2\2TU\7\13\2\2UV\5\20\t\2VW\5\20\t\2WX\7\36\2\2Xq")
        buf.write("\3\2\2\2YZ\7\35\2\2Z[\7\f\2\2[\\\5\20\t\2\\]\5\20\t\2")
        buf.write("]^\7\36\2\2^q\3\2\2\2_`\7\35\2\2`a\7\r\2\2ab\5\20\t\2")
        buf.write("bc\5\20\t\2cd\7\36\2\2dq\3\2\2\2ef\7\35\2\2fg\7\16\2\2")
        buf.write("gh\5\20\t\2hi\5\20\t\2ij\7\36\2\2jq\3\2\2\2kl\7\35\2\2")
        buf.write("lm\7\17\2\2mn\5\20\t\2no\7\36\2\2oq\3\2\2\2p.\3\2\2\2")
        buf.write("p/\3\2\2\2p\65\3\2\2\2p;\3\2\2\2pA\3\2\2\2pG\3\2\2\2p")
        buf.write("M\3\2\2\2pS\3\2\2\2pY\3\2\2\2p_\3\2\2\2pe\3\2\2\2pk\3")
        buf.write("\2\2\2q\r\3\2\2\2rs\t\4\2\2s\17\3\2\2\2t\u009c\5\16\b")
        buf.write("\2u\u009c\5\2\2\2vw\7\35\2\2wx\7\22\2\2xy\5\20\t\2yz\5")
        buf.write("\20\t\2z{\7\36\2\2{\u009c\3\2\2\2|}\7\35\2\2}~\7\23\2")
        buf.write("\2~\177\5\24\13\2\177\u0080\5\20\t\2\u0080\u0081\7\36")
        buf.write("\2\2\u0081\u009c\3\2\2\2\u0082\u0083\7\35\2\2\u0083\u0084")
        buf.write("\7\24\2\2\u0084\u0085\5\24\13\2\u0085\u0086\5\24\13\2")
        buf.write("\u0086\u0087\7\36\2\2\u0087\u009c\3\2\2\2\u0088\u0089")
        buf.write("\7\35\2\2\u0089\u008a\7\25\2\2\u008a\u008b\5\20\t\2\u008b")
        buf.write("\u008c\5\20\t\2\u008c\u008d\5\20\t\2\u008d\u008e\7\36")
        buf.write("\2\2\u008e\u009c\3\2\2\2\u008f\u0090\7\35\2\2\u0090\u0091")
        buf.write("\7\26\2\2\u0091\u0092\5\20\t\2\u0092\u0093\5\20\t\2\u0093")
        buf.write("\u0094\5\20\t\2\u0094\u0095\7\36\2\2\u0095\u009c\3\2\2")
        buf.write("\2\u0096\u0097\7\35\2\2\u0097\u0098\7\27\2\2\u0098\u0099")
        buf.write("\5\24\13\2\u0099\u009a\7\36\2\2\u009a\u009c\3\2\2\2\u009b")
        buf.write("t\3\2\2\2\u009bu\3\2\2\2\u009bv\3\2\2\2\u009b|\3\2\2\2")
        buf.write("\u009b\u0082\3\2\2\2\u009b\u0088\3\2\2\2\u009b\u008f\3")
        buf.write("\2\2\2\u009b\u0096\3\2\2\2\u009c\21\3\2\2\2\u009d\u009e")
        buf.write("\t\5\2\2\u009e\23\3\2\2\2\u009f\u00a6\5\22\n\2\u00a0\u00a1")
        buf.write("\7\35\2\2\u00a1\u00a2\7\32\2\2\u00a2\u00a3\5\20\t\2\u00a3")
        buf.write("\u00a4\7\36\2\2\u00a4\u00a6\3\2\2\2\u00a5\u009f\3\2\2")
        buf.write("\2\u00a5\u00a0\3\2\2\2\u00a6\25\3\2\2\2\u00a7\u00a8\7")
        buf.write("\35\2\2\u00a8\u00a9\7\33\2\2\u00a9\u00aa\7\36\2\2\u00aa")
        buf.write("\27\3\2\2\2\u00ab\u00ac\7\35\2\2\u00ac\u00ad\7\34\2\2")
        buf.write("\u00ad\u00ae\5\f\7\2\u00ae\u00af\7\36\2\2\u00af\31\3\2")
        buf.write("\2\2\u00b0\u00b1\5\6\4\2\u00b1\u00b2\5\b\5\2\u00b2\u00b3")
        buf.write("\5\30\r\2\u00b3\u00b4\5\26\f\2\u00b4\u00b5\7\2\2\3\u00b5")
        buf.write("\33\3\2\2\2\5p\u009b\u00a5")
        return buf.getvalue()


class SMTLIBv2Parser ( Parser ):

    grammarFileName = "SMTLIBv2.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'a'", "'b'", "'String'", "'declare-const'", 
                     "'true'", "'false'", "'='", "'distinct'", "'str.<='", 
                     "'str.prefixof'", "'str.suffixof'", "'str.contains'", 
                     "'str.is_digit'", "'\"\"'", "'\"a\"'", "'str.++'", 
                     "'str.at'", "'str.substr'", "'str.replace'", "'str.replace_all'", 
                     "'str.from_int'", "'0'", "'1'", "'str.to_int'", "'check-sat'", 
                     "'assert'", "'('", "')'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "ParOpen", 
                      "ParClose" ]

    RULE_var_name = 0
    RULE_var_type = 1
    RULE_declareConsta = 2
    RULE_declareConstb = 3
    RULE_boolean = 4
    RULE_bool_term = 5
    RULE_string = 6
    RULE_str_term = 7
    RULE_integer = 8
    RULE_integer_term = 9
    RULE_checkSat = 10
    RULE_assertStatement = 11
    RULE_start = 12

    ruleNames =  [ "var_name", "var_type", "declareConsta", "declareConstb", 
                   "boolean", "bool_term", "string", "str_term", "integer", 
                   "integer_term", "checkSat", "assertStatement", "start" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    ParOpen=27
    ParClose=28

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.9.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Var_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_var_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVar_name" ):
                listener.enterVar_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVar_name" ):
                listener.exitVar_name(self)




    def var_name(self):

        localctx = SMTLIBv2Parser.Var_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_var_name)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 26
            _la = self._input.LA(1)
            if not(_la==SMTLIBv2Parser.T__0 or _la==SMTLIBv2Parser.T__1):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Var_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_var_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVar_type" ):
                listener.enterVar_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVar_type" ):
                listener.exitVar_type(self)




    def var_type(self):

        localctx = SMTLIBv2Parser.Var_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_var_type)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 28
            self.match(SMTLIBv2Parser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclareConstaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ParOpen(self):
            return self.getToken(SMTLIBv2Parser.ParOpen, 0)

        def var_type(self):
            return self.getTypedRuleContext(SMTLIBv2Parser.Var_typeContext,0)


        def ParClose(self):
            return self.getToken(SMTLIBv2Parser.ParClose, 0)

        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_declareConsta

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclareConsta" ):
                listener.enterDeclareConsta(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclareConsta" ):
                listener.exitDeclareConsta(self)




    def declareConsta(self):

        localctx = SMTLIBv2Parser.DeclareConstaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_declareConsta)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 30
            self.match(SMTLIBv2Parser.ParOpen)
            self.state = 31
            self.match(SMTLIBv2Parser.T__3)
            self.state = 32
            self.match(SMTLIBv2Parser.T__0)
            self.state = 33
            self.var_type()
            self.state = 34
            self.match(SMTLIBv2Parser.ParClose)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclareConstbContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ParOpen(self):
            return self.getToken(SMTLIBv2Parser.ParOpen, 0)

        def var_type(self):
            return self.getTypedRuleContext(SMTLIBv2Parser.Var_typeContext,0)


        def ParClose(self):
            return self.getToken(SMTLIBv2Parser.ParClose, 0)

        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_declareConstb

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclareConstb" ):
                listener.enterDeclareConstb(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclareConstb" ):
                listener.exitDeclareConstb(self)




    def declareConstb(self):

        localctx = SMTLIBv2Parser.DeclareConstbContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_declareConstb)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 36
            self.match(SMTLIBv2Parser.ParOpen)
            self.state = 37
            self.match(SMTLIBv2Parser.T__3)
            self.state = 38
            self.match(SMTLIBv2Parser.T__1)
            self.state = 39
            self.var_type()
            self.state = 40
            self.match(SMTLIBv2Parser.ParClose)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BooleanContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_boolean

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBoolean" ):
                listener.enterBoolean(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBoolean" ):
                listener.exitBoolean(self)




    def boolean(self):

        localctx = SMTLIBv2Parser.BooleanContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_boolean)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 42
            _la = self._input.LA(1)
            if not(_la==SMTLIBv2Parser.T__4 or _la==SMTLIBv2Parser.T__5):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bool_termContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def boolean(self):
            return self.getTypedRuleContext(SMTLIBv2Parser.BooleanContext,0)


        def ParOpen(self):
            return self.getToken(SMTLIBv2Parser.ParOpen, 0)

        def str_term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SMTLIBv2Parser.Str_termContext)
            else:
                return self.getTypedRuleContext(SMTLIBv2Parser.Str_termContext,i)


        def ParClose(self):
            return self.getToken(SMTLIBv2Parser.ParClose, 0)

        def integer_term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SMTLIBv2Parser.Integer_termContext)
            else:
                return self.getTypedRuleContext(SMTLIBv2Parser.Integer_termContext,i)


        def bool_term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SMTLIBv2Parser.Bool_termContext)
            else:
                return self.getTypedRuleContext(SMTLIBv2Parser.Bool_termContext,i)


        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_bool_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBool_term" ):
                listener.enterBool_term(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBool_term" ):
                listener.exitBool_term(self)




    def bool_term(self):

        localctx = SMTLIBv2Parser.Bool_termContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_bool_term)
        try:
            self.state = 110
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 44
                self.boolean()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 45
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 46
                self.match(SMTLIBv2Parser.T__6)
                self.state = 47
                self.str_term()
                self.state = 48
                self.str_term()
                self.state = 49
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 51
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 52
                self.match(SMTLIBv2Parser.T__6)
                self.state = 53
                self.integer_term()
                self.state = 54
                self.integer_term()
                self.state = 55
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 57
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 58
                self.match(SMTLIBv2Parser.T__6)
                self.state = 59
                self.bool_term()
                self.state = 60
                self.bool_term()
                self.state = 61
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 63
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 64
                self.match(SMTLIBv2Parser.T__7)
                self.state = 65
                self.str_term()
                self.state = 66
                self.str_term()
                self.state = 67
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 69
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 70
                self.match(SMTLIBv2Parser.T__7)
                self.state = 71
                self.integer_term()
                self.state = 72
                self.integer_term()
                self.state = 73
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 75
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 76
                self.match(SMTLIBv2Parser.T__7)
                self.state = 77
                self.bool_term()
                self.state = 78
                self.bool_term()
                self.state = 79
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 81
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 82
                self.match(SMTLIBv2Parser.T__8)
                self.state = 83
                self.str_term()
                self.state = 84
                self.str_term()
                self.state = 85
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 87
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 88
                self.match(SMTLIBv2Parser.T__9)
                self.state = 89
                self.str_term()
                self.state = 90
                self.str_term()
                self.state = 91
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 10:
                self.enterOuterAlt(localctx, 10)
                self.state = 93
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 94
                self.match(SMTLIBv2Parser.T__10)
                self.state = 95
                self.str_term()
                self.state = 96
                self.str_term()
                self.state = 97
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 11:
                self.enterOuterAlt(localctx, 11)
                self.state = 99
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 100
                self.match(SMTLIBv2Parser.T__11)
                self.state = 101
                self.str_term()
                self.state = 102
                self.str_term()
                self.state = 103
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 12:
                self.enterOuterAlt(localctx, 12)
                self.state = 105
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 106
                self.match(SMTLIBv2Parser.T__12)
                self.state = 107
                self.str_term()
                self.state = 108
                self.match(SMTLIBv2Parser.ParClose)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_string

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterString" ):
                listener.enterString(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitString" ):
                listener.exitString(self)




    def string(self):

        localctx = SMTLIBv2Parser.StringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_string)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 112
            _la = self._input.LA(1)
            if not(_la==SMTLIBv2Parser.T__13 or _la==SMTLIBv2Parser.T__14):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Str_termContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def string(self):
            return self.getTypedRuleContext(SMTLIBv2Parser.StringContext,0)


        def var_name(self):
            return self.getTypedRuleContext(SMTLIBv2Parser.Var_nameContext,0)


        def ParOpen(self):
            return self.getToken(SMTLIBv2Parser.ParOpen, 0)

        def str_term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SMTLIBv2Parser.Str_termContext)
            else:
                return self.getTypedRuleContext(SMTLIBv2Parser.Str_termContext,i)


        def ParClose(self):
            return self.getToken(SMTLIBv2Parser.ParClose, 0)

        def integer_term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SMTLIBv2Parser.Integer_termContext)
            else:
                return self.getTypedRuleContext(SMTLIBv2Parser.Integer_termContext,i)


        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_str_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStr_term" ):
                listener.enterStr_term(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStr_term" ):
                listener.exitStr_term(self)




    def str_term(self):

        localctx = SMTLIBv2Parser.Str_termContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_str_term)
        try:
            self.state = 153
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 114
                self.string()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 115
                self.var_name()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 116
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 117
                self.match(SMTLIBv2Parser.T__15)
                self.state = 118
                self.str_term()
                self.state = 119
                self.str_term()
                self.state = 120
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 122
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 123
                self.match(SMTLIBv2Parser.T__16)
                self.state = 124
                self.integer_term()
                self.state = 125
                self.str_term()
                self.state = 126
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 128
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 129
                self.match(SMTLIBv2Parser.T__17)
                self.state = 130
                self.integer_term()
                self.state = 131
                self.integer_term()
                self.state = 132
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 134
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 135
                self.match(SMTLIBv2Parser.T__18)
                self.state = 136
                self.str_term()
                self.state = 137
                self.str_term()
                self.state = 138
                self.str_term()
                self.state = 139
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 141
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 142
                self.match(SMTLIBv2Parser.T__19)
                self.state = 143
                self.str_term()
                self.state = 144
                self.str_term()
                self.state = 145
                self.str_term()
                self.state = 146
                self.match(SMTLIBv2Parser.ParClose)
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 148
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 149
                self.match(SMTLIBv2Parser.T__20)
                self.state = 150
                self.integer_term()
                self.state = 151
                self.match(SMTLIBv2Parser.ParClose)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntegerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_integer

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInteger" ):
                listener.enterInteger(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInteger" ):
                listener.exitInteger(self)




    def integer(self):

        localctx = SMTLIBv2Parser.IntegerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_integer)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 155
            _la = self._input.LA(1)
            if not(_la==SMTLIBv2Parser.T__21 or _la==SMTLIBv2Parser.T__22):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Integer_termContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def integer(self):
            return self.getTypedRuleContext(SMTLIBv2Parser.IntegerContext,0)


        def ParOpen(self):
            return self.getToken(SMTLIBv2Parser.ParOpen, 0)

        def str_term(self):
            return self.getTypedRuleContext(SMTLIBv2Parser.Str_termContext,0)


        def ParClose(self):
            return self.getToken(SMTLIBv2Parser.ParClose, 0)

        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_integer_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInteger_term" ):
                listener.enterInteger_term(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInteger_term" ):
                listener.exitInteger_term(self)




    def integer_term(self):

        localctx = SMTLIBv2Parser.Integer_termContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_integer_term)
        try:
            self.state = 163
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [SMTLIBv2Parser.T__21, SMTLIBv2Parser.T__22]:
                self.enterOuterAlt(localctx, 1)
                self.state = 157
                self.integer()
                pass
            elif token in [SMTLIBv2Parser.ParOpen]:
                self.enterOuterAlt(localctx, 2)
                self.state = 158
                self.match(SMTLIBv2Parser.ParOpen)
                self.state = 159
                self.match(SMTLIBv2Parser.T__23)
                self.state = 160
                self.str_term()
                self.state = 161
                self.match(SMTLIBv2Parser.ParClose)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CheckSatContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ParOpen(self):
            return self.getToken(SMTLIBv2Parser.ParOpen, 0)

        def ParClose(self):
            return self.getToken(SMTLIBv2Parser.ParClose, 0)

        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_checkSat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCheckSat" ):
                listener.enterCheckSat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCheckSat" ):
                listener.exitCheckSat(self)




    def checkSat(self):

        localctx = SMTLIBv2Parser.CheckSatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_checkSat)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 165
            self.match(SMTLIBv2Parser.ParOpen)
            self.state = 166
            self.match(SMTLIBv2Parser.T__24)
            self.state = 167
            self.match(SMTLIBv2Parser.ParClose)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssertStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ParOpen(self):
            return self.getToken(SMTLIBv2Parser.ParOpen, 0)

        def bool_term(self):
            return self.getTypedRuleContext(SMTLIBv2Parser.Bool_termContext,0)


        def ParClose(self):
            return self.getToken(SMTLIBv2Parser.ParClose, 0)

        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_assertStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssertStatement" ):
                listener.enterAssertStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssertStatement" ):
                listener.exitAssertStatement(self)




    def assertStatement(self):

        localctx = SMTLIBv2Parser.AssertStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_assertStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 169
            self.match(SMTLIBv2Parser.ParOpen)
            self.state = 170
            self.match(SMTLIBv2Parser.T__25)
            self.state = 171
            self.bool_term()
            self.state = 172
            self.match(SMTLIBv2Parser.ParClose)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def declareConsta(self):
            return self.getTypedRuleContext(SMTLIBv2Parser.DeclareConstaContext,0)


        def declareConstb(self):
            return self.getTypedRuleContext(SMTLIBv2Parser.DeclareConstbContext,0)


        def assertStatement(self):
            return self.getTypedRuleContext(SMTLIBv2Parser.AssertStatementContext,0)


        def checkSat(self):
            return self.getTypedRuleContext(SMTLIBv2Parser.CheckSatContext,0)


        def EOF(self):
            return self.getToken(SMTLIBv2Parser.EOF, 0)

        def getRuleIndex(self):
            return SMTLIBv2Parser.RULE_start

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStart" ):
                listener.enterStart(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStart" ):
                listener.exitStart(self)




    def start(self):

        localctx = SMTLIBv2Parser.StartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_start)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 174
            self.declareConsta()
            self.state = 175
            self.declareConstb()
            self.state = 176
            self.assertStatement()
            self.state = 177
            self.checkSat()
            self.state = 178
            self.match(SMTLIBv2Parser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





