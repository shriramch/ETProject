# Generated from SMTLIBv2.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .SMTLIBv2Parser import SMTLIBv2Parser
else:
    from SMTLIBv2Parser import SMTLIBv2Parser

# This class defines a complete listener for a parse tree produced by SMTLIBv2Parser.
class SMTLIBv2Listener(ParseTreeListener):

    # Enter a parse tree produced by SMTLIBv2Parser#var_name.
    def enterVar_name(self, ctx:SMTLIBv2Parser.Var_nameContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#var_name.
    def exitVar_name(self, ctx:SMTLIBv2Parser.Var_nameContext):
        pass


    # Enter a parse tree produced by SMTLIBv2Parser#var_type.
    def enterVar_type(self, ctx:SMTLIBv2Parser.Var_typeContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#var_type.
    def exitVar_type(self, ctx:SMTLIBv2Parser.Var_typeContext):
        pass


    # Enter a parse tree produced by SMTLIBv2Parser#declareConsta.
    def enterDeclareConsta(self, ctx:SMTLIBv2Parser.DeclareConstaContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#declareConsta.
    def exitDeclareConsta(self, ctx:SMTLIBv2Parser.DeclareConstaContext):
        pass


    # Enter a parse tree produced by SMTLIBv2Parser#declareConstb.
    def enterDeclareConstb(self, ctx:SMTLIBv2Parser.DeclareConstbContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#declareConstb.
    def exitDeclareConstb(self, ctx:SMTLIBv2Parser.DeclareConstbContext):
        pass


    # Enter a parse tree produced by SMTLIBv2Parser#boolean.
    def enterBoolean(self, ctx:SMTLIBv2Parser.BooleanContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#boolean.
    def exitBoolean(self, ctx:SMTLIBv2Parser.BooleanContext):
        pass


    # Enter a parse tree produced by SMTLIBv2Parser#bool_term.
    def enterBool_term(self, ctx:SMTLIBv2Parser.Bool_termContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#bool_term.
    def exitBool_term(self, ctx:SMTLIBv2Parser.Bool_termContext):
        pass


    # Enter a parse tree produced by SMTLIBv2Parser#string.
    def enterString(self, ctx:SMTLIBv2Parser.StringContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#string.
    def exitString(self, ctx:SMTLIBv2Parser.StringContext):
        pass


    # Enter a parse tree produced by SMTLIBv2Parser#str_term.
    def enterStr_term(self, ctx:SMTLIBv2Parser.Str_termContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#str_term.
    def exitStr_term(self, ctx:SMTLIBv2Parser.Str_termContext):
        pass


    # Enter a parse tree produced by SMTLIBv2Parser#integer.
    def enterInteger(self, ctx:SMTLIBv2Parser.IntegerContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#integer.
    def exitInteger(self, ctx:SMTLIBv2Parser.IntegerContext):
        pass


    # Enter a parse tree produced by SMTLIBv2Parser#integer_term.
    def enterInteger_term(self, ctx:SMTLIBv2Parser.Integer_termContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#integer_term.
    def exitInteger_term(self, ctx:SMTLIBv2Parser.Integer_termContext):
        pass


    # Enter a parse tree produced by SMTLIBv2Parser#checkSat.
    def enterCheckSat(self, ctx:SMTLIBv2Parser.CheckSatContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#checkSat.
    def exitCheckSat(self, ctx:SMTLIBv2Parser.CheckSatContext):
        pass


    # Enter a parse tree produced by SMTLIBv2Parser#assertStatement.
    def enterAssertStatement(self, ctx:SMTLIBv2Parser.AssertStatementContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#assertStatement.
    def exitAssertStatement(self, ctx:SMTLIBv2Parser.AssertStatementContext):
        pass


    # Enter a parse tree produced by SMTLIBv2Parser#start.
    def enterStart(self, ctx:SMTLIBv2Parser.StartContext):
        pass

    # Exit a parse tree produced by SMTLIBv2Parser#start.
    def exitStart(self, ctx:SMTLIBv2Parser.StartContext):
        pass



del SMTLIBv2Parser