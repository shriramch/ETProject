exhaustive_enumerator
=====================

